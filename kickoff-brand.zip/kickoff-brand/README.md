# Kickoff — pacote de marca

Marca gerada a partir do conceito "K" (base sólida + faísca de lançamento).
Wordmark: Inter ExtraBold (já convertido para vetor, não depende da fonte instalada).

## Paleta
| Cor            | Hex       | Uso                          |
|----------------|-----------|------------------------------|
| Bordô          | `#7A1E2D` | cor primária / acentos       |
| Bordô profundo | `#5A1521` | variação sóbria / hover      |
| Faísca (vivo)  | `#A12E44` | o ponto de "launch" no ícone |
| Preto / ink    | `#17151A` | fundo do ícone, texto        |
| Off-white      | `#F3EEE8` | marca sobre fundo escuro     |

## Arquivos

### svg/ (fontes editáveis)
- `kickoff-mark.svg` — só o "K" (ink), para fundo claro
- `kickoff-mark-inverse.svg` — só o "K" (off-white), para fundo escuro
- `kickoff-icon.svg` — ícone do app (tile preto)
- `kickoff-icon-bordo.svg` — variação do ícone em bordô
- `kickoff-lockup.svg` — horizontal (ícone + "kickoff"), fundo claro
- `kickoff-lockup-inverse.svg` — horizontal, fundo escuro

### png/
- `icon-16…1024.png` — ícone em todos os tamanhos
- `mark-512.png` / `mark-inverse-512.png` — só o "K", transparente
- `lockup.png` / `lockup-inverse.png` — horizontal

## Onde usar no projeto

1. **Manifesto** — princípio nº5 (logo como caminho de arquivo):
   `.project/logo.png` já está pronto (512×512). Copie para a raiz do projeto-alvo.

2. **Favicon do renderer** (Vite) — coloque `favicon.ico` em
   `src/renderer/public/` e referencie no `index.html`:
   `<link rel="icon" href="/favicon.ico">`

3. **Ícones do electron-builder** — copie a pasta `build/` para a raiz do repo.
   O electron-builder lê `build/icon.ico` (Windows), `build/icon.icns` (macOS)
   e `build/icon.png` (Linux) automaticamente, sem config extra.

> Obs.: o `icon.icns` foi gerado fora do macOS. Funciona, mas se notar qualquer
> problema no build do .dmg, regere no macOS com `iconutil` ou rode o build via CI.
